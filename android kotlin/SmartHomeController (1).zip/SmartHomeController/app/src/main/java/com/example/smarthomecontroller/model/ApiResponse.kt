package com.example.smarthomecontroller.model



data class ApiResponse(
    val success: Boolean,
    val message: String
)
