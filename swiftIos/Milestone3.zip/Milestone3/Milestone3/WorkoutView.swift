//
//  WorkoutView.swift
//  Milestone3
//
//  Created by admin on 04/02/25.
//

import SwiftUI
import CoreData

struct WorkoutView: View {
    @Environment(\.managedObjectContext) private var viewContext
    @FetchRequest(
        entity: Workout.entity(),
        sortDescriptors: []
    ) private var workouts: FetchedResults<Workout>
    
    @State private var showAddWorkout = false
    @State private var WorkoutToEdit: Workout?
    
    var body: some View {
        NavigationView {
            VStack{
                List {
                    ForEach(workouts){ workout in
                        NavigationLink(destination: EditWorkoutView(workout : workout)){
                            HStack {
                                VStack(alignment: .leading ){
                                    Text(workout.exerciseName ?? "No name")
                                    Text("\(workout.duration, specifier: "%.2f")").font(.headline)
                                    Text("\(workout.caloriesBurned, specifier: "%.2f")")
                                    
                                }
                            }
                        }
                        .buttonStyle(PlainButtonStyle())
                        
                        .swipeActions {
                            Button(role : .destructive){
                                deleteWorkout(workout)
                            } label: {
                                Label("Delete", systemImage: "trash")
                            }
                        }
                        
                    }
                }
            }
            
            .navigationTitle("All Workout")
            .toolbar{
                ToolbarItem(placement: .navigationBarTrailing){
                    Button(action:{
                        showAddWorkout = true
                    }){
                        Image(systemName: "plus")
                    }
                        
                    
                }
            }
            .sheet(isPresented: $showAddWorkout){
                AddWorkoutView()
            }
        }
    }
    private func deleteWorkout(_ workout: Workout){
        viewContext.delete(workout)
        do {
            try viewContext.save()
        }catch {
            print("Error deleting post: \(error)")
        }
    }
}

struct WorkoutView_Previews: PreviewProvider {
    static var previews: some View {
        WorkoutView()
    }
}
