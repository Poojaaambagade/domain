//
//  Milestone3App.swift
//  Milestone3
//
//  Created by admin on 04/02/25.
//

import SwiftUI

@main
struct Milestone3App: App {
    let persistentController = PersistenceController.shared
    var body: some Scene {
        WindowGroup {
            WorkoutView()
                .environment(\.managedObjectContext, persistentController.container.viewContext)
        }
    }
}
