//
//  AddWorkoutView.swift
//  Milestone3
//
//  Created by admin on 04/02/25.
//

import SwiftUI

struct AddWorkoutView: View {
    
    @Environment(\.managedObjectContext) private var viewContext
    @Environment(\.dismiss) private var dismiss
    @State private var exerciseName = ""
    @State private var duration = ""
    @State private var caloriesBurned = ""
    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("Workout Details")){
                    TextField("Enter Name", text: $exerciseName)
                    TextField("Duration", text: $duration)
                    TextField("Calories Burned", text: $caloriesBurned)
                    
                }
                .navigationBarTitle("Add New Workout", displayMode: .inline)
                .navigationBarItems(
                    leading: Button("Cancle"){
                        dismiss()
                    },
                    trailing: Button("Save"){
                        addWorkout()
                        dismiss()
                    }
                        .disabled(exerciseName.isEmpty)
                )
            }
        }
        
    }
    
    private func addWorkout(){
        let newWorkout = Workout(context: viewContext)
        newWorkout.exerciseName = exerciseName
        
        if let isDouble = Double(duration){
            newWorkout.duration = isDouble
        }
        else {
            newWorkout.duration = 0.0
        }
        
        if let isDoubleNew = Double(caloriesBurned){
            newWorkout.caloriesBurned = isDoubleNew
        }
        else {
            newWorkout.caloriesBurned = 0.0
        }
        
        do{
            try viewContext.save()
            exerciseName = ""
            duration = ""
            caloriesBurned = ""
        }catch{
            print("Error saving Workout : \(error)")
        }
        
    }
}

struct AddWorkoutView_Previews: PreviewProvider {
    static var previews: some View {
        AddWorkoutView()
    }
}
