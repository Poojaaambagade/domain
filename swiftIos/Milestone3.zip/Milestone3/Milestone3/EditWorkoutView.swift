//
//  EditWorkoutView.swift
//  Milestone3
//
//  Created by admin on 04/02/25.
//

import SwiftUI

struct EditWorkoutView: View {
    
    @Environment(\.managedObjectContext) private var viewContext
    @Environment(\.dismiss) private var dismiss
    @ObservedObject var workout: Workout
    @State private var exerciseName = ""
    @State private var duration = ""
    
    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("Edit Workout")){
                    TextField("Edit Name", text:$exerciseName)
                    TextField("Edit Duration", text:$duration)
                }
            }
            .navigationBarTitle("Edit Workout", displayMode: .inline)
            .navigationBarItems(
                leading: Button("Cancle"){
                    dismiss()
                },
                trailing: Button("Update"){
                    if let isDouble = Double(duration){
                        workout.duration = isDouble
                    }else{
                        workout.duration = 0.0
                    }
                    workout.exerciseName = exerciseName
                    saveContext()
                    dismiss()
                }.disabled(exerciseName.isEmpty)
            )
            .onAppear{
                duration = String(format: "%2f", workout.duration)
                exerciseName = workout.exerciseName ?? ""
            }
        }
    }
    private func saveContext(){
        do {
            try viewContext.save()
        }catch{
            print("Error saving context: \(error)")
        }
    }
}

