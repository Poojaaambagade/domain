//
//  EditPostView.swift
//  SampleApp
//
//  Created by admin on 30/01/25.
//

import SwiftUI

struct EditPostView: View {
    
    @Environment(\.managedObjectContext) private var viewContext
    @Environment(\.dismiss) private var dismiss
    
    @ObservedObject var post:Post
    @State private var title = ""
    @State private var desc = ""
    
    var body: some View {
        
        NavigationView {
            Form {
                Section(header: Text("Edit Title")){
                    TextField("Title", text: $title)
                    TextField("Description", text: $desc)
                }  //section
            } //form
            .navigationBarTitle("Edit Post", displayMode: .inline)
            .navigationBarItems(
                leading: Button("Cancle"){
                   dismiss()
                },
                trailing: Button("Update"){
                    post.title = title
                    post.desc = desc
                    saveContext()
                    dismiss()
                }.disabled(title.isEmpty)
            )  //navbarItem
            .onAppear{
                title = post.title ?? ""
                desc = post.desc ?? ""
            }
        }  //navview
    }  //view
    
    private func saveContext(){
        do {
            try viewContext.save()
        }catch {
            print("Error saving context: \(error)")
        }
    }   // func savecontext
}  // struct

