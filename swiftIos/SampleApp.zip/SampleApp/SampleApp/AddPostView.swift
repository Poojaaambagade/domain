//
//  AddPostView.swift
//  SampleApp
//
//  Created by admin on 30/01/25.
//

import SwiftUI

struct AddPostView: View {
    
    @Environment(\.managedObjectContext) private var viewContext
    @Environment(\.dismiss) private var dismiss
    
    @State private var title = ""
    @State private var desc = ""
    
    var body: some View {
        
        NavigationView{
            Form {
                Section(header: Text("Post Title")){
                    TextField("Enter The Title", text:$title)
                    TextField("Enter The Description", text:$desc)
                }  // section
            } // form
            .navigationBarTitle("Add New Post", displayMode: .inline)
            .navigationBarItems(
                
                leading: Button("Cancle"){
                    
                    dismiss()
                    
                },
                trailing: Button("Save"){
                    
                    addPost()
                    dismiss()
                }.disabled(title.isEmpty)
            )  // navBarItem
        } // navView
      
     }// view

     private func addPost(){
         
         let newPost = Post(context: viewContext)
         
         newPost.title = title
         newPost.desc = desc
         
         do{
             try viewContext.save()
         } catch{
             print("Error saving post: \(error)")
           }
     }  // fun addpost
  }//struct

struct AddPostView_Previews: PreviewProvider {
    static var previews: some View {
        AddPostView()
    }
}
