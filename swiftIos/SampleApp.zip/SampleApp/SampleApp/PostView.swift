//
//  PostView.swift
//  SampleApp
//
//  Created by admin on 30/01/25.
//

import SwiftUI
import CoreData

struct PostView: View {
    
    @Environment(\.managedObjectContext) private var viewContext
    
    @FetchRequest(
        entity : Post.entity(),
        sortDescriptors: []
    ) private var posts : FetchedResults<Post>
    
    @State private var showAddView = false
    @State private var postToEdit: Post?
    
    
    var body: some View {
        
        NavigationView {
            List{
                ForEach(posts) { post in
                    NavigationLink(destination: EditPostView(post: post)) {
                        HStack {
                            VStack{
                                Text(post.title ?? "No Title")
                                Text(post.desc ?? "No description")
                                
                            }   //vstack
                        }    // hstack
                    }  // navLink
                    .buttonStyle(PlainButtonStyle())
                    
                    .swipeActions {
                        Button(role: .destructive){
                            deletePost(post)
                        } label: {
                            Label("Delete", systemImage: "trash")
                        }  // lbl
                    }  // swipeaction
                }  // foreach
             }  // list
            .navigationTitle("All Posts")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing ){
                    Button(action : {
                        showAddView = true
                    }){
                        Image(systemName: "plus")
                        
                    }
               }      // toolbarItem
            }  // toolbar
            .sheet(isPresented: $showAddView){
                AddPostView()
            }
         }  // navView
     }  // view
    
    private func deletePost(_ post: Post){
        viewContext.delete(post)
        do {
            try viewContext.save()
        }catch{
            print("Error deleting post: \(error)")
        }
    }
 } //struct

struct PostView_Previews: PreviewProvider {
    static var previews: some View {
        PostView()
    }
}
