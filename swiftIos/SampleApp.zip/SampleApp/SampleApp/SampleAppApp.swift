//
//  SampleAppApp.swift
//  SampleApp
//
//  Created by admin on 30/01/25.
//

import SwiftUI

@main
struct SampleAppApp: App {
    
    let persistentController = PersistenceController.shared
    var body: some Scene {
        WindowGroup {
              PostView()
                .environment(\.managedObjectContext, persistentController.container.viewContext)
        }
    }
}
