//
//  BudgetTrackerNewAppApp.swift
//  BudgetTrackerNewApp
//
//  Created by admin on 31/01/25.
//

import SwiftUI

@main
struct BudgetTrackerNewAppApp: App {
    
    let persistentController = PersistenceController.shared
    var body: some Scene {
        WindowGroup {
            LoginView()
           // TransactionView()
                .environment(\.managedObjectContext, persistentController.container.viewContext)
        }
    }
}
