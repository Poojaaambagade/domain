//
//  FitnessAppApp.swift
//  FitnessApp
//
//  Created by admin on 01/02/25.
//

import SwiftUI

@main
struct FitnessAppApp: App {
    
    let persistentController = PersistenceController.shared
    
    var body: some Scene {
        WindowGroup {
            WorkoutListView()
                .environment(\.managedObjectContext, persistentController.container.viewContext)
        }
    }
}
