//
//  AddMedicineView.swift
//  Medicine
//
//  Created by admin on 04/02/25.
//

import SwiftUI

struct AddMedicineView: View {
    @Environment(\.managedObjectContext) private var viewContext
    @Environment(\.dismiss) private var dismiss
    @State private var name = ""
    @State private var frequency = ""
    @State private var dosage = ""
    
    var body: some View {
        NavigationView{
            Form {
                Section(header: Text("Medicine Title")){
                    TextField("Enter Medicine Name", text:$name)
                    TextField("Enter Dosage", text:$dosage)
                        .keyboardType(.decimalPad)
                }
                .navigationBarTitle("Add New Medicines", displayMode: .inline)
                .navigationBarItems(
                    leading: Button("Cancle"){
                        dismiss()
                    },
                    trailing: Button("Save"){
                        addMedicine()
                        dismiss()
                    }
                        .disabled(name.isEmpty)
                )
            }
        }
    }
    private func addMedicine(){
        let newMedicine = Medicine(context: viewContext)
        newMedicine.name = name
        newMedicine.frequency = frequency
        if let isFloat = Float(dosage){
            newMedicine.dosage = isFloat
        }
        else {
            newMedicine.dosage = 0.0
        }
        
        do{
            try viewContext.save()
            
        }catch{
            print("Error saving Medicines (error)")
        }
        
    }
}

struct AddMedicineView_Previews: PreviewProvider {
    static var previews: some View {
        AddMedicineView()
    }
}
