//
//  EditMedicineView.swift
//  Medicine
//
//  Created by admin on 04/02/25.
//

import SwiftUI

struct EditMedicineView: View {
    
    @Environment(\.managedObjectContext) private var viewContext
    @Environment(\.dismiss) private var dismiss
    @ObservedObject var medicine: Medicine
    @State private var name = ""
    @State private var frequency = ""
    
    var body: some View {
        NavigationView{
            Form {
                Section(header:Text("Edit Medicines")) {
                    TextField("Edit Medicine Name", text:$name)
                    TextField("Edit Medicine Frequency", text:$frequency)
                }
            }
            .navigationBarTitle("Edit Medicines", displayMode: .inline)
            .navigationBarItems(
                leading: Button("Cancle"){
                    dismiss()
                },
                trailing: Button("Update"){
                    medicine.name = name
                    medicine.frequency = frequency
                    saveContext()
                    dismiss()
                }
                    .disabled(name.isEmpty)
            )
            .onAppear{
                name = medicine.name ?? ""
                frequency = medicine.frequency ?? ""
            
            }
        }
    }
    
    private func saveContext(){
        do {
            try viewContext.save()
        }catch{
            print("Error saving context: \(error)")
        }
    }
}

