//
//  MedicineView.swift
//  Medicine
//
//  Created by admin on 04/02/25.
//

import SwiftUI
import CoreData

struct MedicineView: View {
    @Environment(\.managedObjectContext) private var viewContext
    @FetchRequest(
        entity: Medicine.entity(),
        sortDescriptors: []
    ) private var medicines : FetchedResults<Medicine>
    
    @State private var showAddMedicine = false
    @State private var medicineToEdit:Medicine?
    
    var body: some View {
        NavigationView{
            List {
                ForEach(medicines){ medicine in
                    NavigationLink(destination: EditMedicineView(medicine:medicine)){
                        HStack{
                            VStack(alignment: .leading){
                                Text(medicine.name ?? "No Name").font(.title)
                                Text(medicine.frequency ?? "No frequency")
                                Text("\(medicine.dosage, specifier:"%.2f")")
                            }
                        }
                    }
                    .buttonStyle(PlainButtonStyle())
                    .swipeActions {
                        Button(role: .destructive){
                            deleteMedicine(medicine)
                        } label : {
                            Label("Delete", systemImage: "trash")
                        }
                    }
                    
                }
            }
            navigationTitle("All Medicines")
                .toolbar {
                    ToolbarItem(placement: .navigationBarTrailing){
                        Button(action : {
                            showAddMedicine = true
                        }){
                            Image(systemName: "plus")
                        }
                    }
                }
                .sheet(isPresented:$showAddMedicine ){
                    AddMedicineView()
                }
        }
    }
    
    private func deleteMedicine(_ medicine:Medicine){
        viewContext.delete(medicine)
        do{
            try viewContext.save()
        }catch{
            print("Error Deleting Medicines: \(error)")
        }
    }
}

struct MedicineView_Previews: PreviewProvider {
    static var previews: some View {
        MedicineView()
    }
}
