//
//  MedicineApp.swift
//  Medicine
//
//  Created by admin on 04/02/25.
//

import SwiftUI

@main
struct MedicineApp: App {
    let persistentController = PersistenceController.shared
    var body: some Scene {
        WindowGroup {
            MedicineView()
                .environment(\.managedObjectContext, persistentController.container.viewContext)
        }
    }
}
