//
//  AddTransactionView.swift
//  BudgetTrackerNew
//
//  Created by admin on 30/01/25.
//

import SwiftUI
struct AddTransactionView: View {
    @Environment(\.managedObjectContext) private var viewContext
    @Environment(\.dismiss) private var dismiss
    
    @State private var desc = ""
    @State private var amount = ""
    
    var body: some View {
        
        NavigationView {
            Form {
                Section(header: Text("Transaction Details")){
                    
                    TextField("Description", text:$desc)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                    
                    TextField("Amount", text:$amount)
                        .keyboardType(.decimalPad)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                    
                    Picker("Category", selection: $category){
                        Text("Income").tag("income")
                        Text("Expense").tag("expense")
                        
                    }
                    .pickerStyle(SegmentedPickerStyle())
                }
            }
            .navigationBarTitle("Add New Transactions", displayMode: .inline)
            .navigationBarItems(
                leading: Button("Cancle"){
                    dismiss()
                },
                trailing: Button("Save"){
                    
                }
            )
        }
    }
}

struct AddTransactionView_Previews: PreviewProvider {
    static var previews: some View {
        AddTransactionView()
    }
}
