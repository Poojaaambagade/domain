//
//  EditTransactionView.swift
//  BudgetTrackerNew
//
//  Created by admin on 30/01/25.
//

import SwiftUI

struct EditTransactionView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct EditTransactionView_Previews: PreviewProvider {
    static var previews: some View {
        EditTransactionView()
    }
}
