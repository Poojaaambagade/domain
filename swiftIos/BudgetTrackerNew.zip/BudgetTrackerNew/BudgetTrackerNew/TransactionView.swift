//
//  TransactionView.swift
//  BudgetTrackerNew
//
//  Created by admin on 30/01/25.
//


import SwiftUI
import CoreData

struct TransactionView: View {
    
    @Environment(\.managedObjectContext) private var viewContext
    
    @FetchRequest(
        entity : Transaction.entity(),
        sortDescriptors: []
    ) private var transactions : FetchedResults<Transaction>
    
    @State private var showAddTransaction = false
    @State private var transactionToEdit: Transaction?
    
    
    var body: some View {
        
        NavigationView {
            List{
                ForEach(transactions) { transaction in
                    NavigationLink(destination: EditTransactionView(transaction: transaction)) {
                        HStack {
                            VStack{
                                Text(transaction.amount ?? "No Amount")
                                Text(transaction.desc ?? "No description")
                                Text(transaction.category ?? "No Category")
                            }
                        }
                    }
                    .buttonStyle(PlainButtonStyle())
                    
                    .swipeActions {
                        Button(role: .destructive){
                            deleteTransaction(transaction)
                        } label: {
                            Label("Delete", systemImage: "trash")
                        }
                    }
                }
             }
            .navigationTitle("All Transaction Details")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing ){
                    Button(action : {
                        showAddTransaction = true
                    }){
                        Image(systemName: "plus")
                        
                    }
               }
            }
            .sheet(isPresented: $showAddTransaction){
                AddTransactionView()
            }
         }
     }
    
    private func deleteTransaction(_ transaction: Transaction){
        viewContext.delete(transaction)
        do {
            try viewContext.save()
        } catch {
            print("Error deleting Transaction: \(error)")
        }
    }
 }


struct TransactionView_Previews: PreviewProvider {
    static var previews: some View {
        TransactionView()
    }
}
