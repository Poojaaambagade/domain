//
//  NotesView.swift
//  Notes
//
//  Created by admin on 01/02/25.
//

import SwiftUI
import CoreData
struct NotesView: View {
    @Environment(\.managedObjectContext) private var viewContext
    @FetchRequest(
        entity: Notes.entity(),
        sortDescriptors: []
    ) private var notes : FetchedResults<Notes>
    
    @State private var showAddNotes = false
    @State private var notesToEdit : Notes?
    
    var body: some View {
        NavigationView {
            VStack {
                List {
                    ForEach(notes){ note in
                        NavigationLink(destination : EditNotesView(note : note)){
                            
                            HStack {
                                VStack(alignment : .leading){
                                    
                                    Text(note.title ?? "No Title").font(.title)
                                    Text(note.content ?? "No Content")
                                    if let date = note.date {
                                        Text(formatDate(date))
                                            .font(.caption)
                                    }
                                 }   //vstack
                            }      // hstack
                        }    // navlink
                        .buttonStyle(PlainButtonStyle())
                        .swipeActions {
                            Button(role : .destructive){
                                deleteNotes(note)
                            } label: {
                                Label("Delete", systemImage: "trash")
                            }
                        }   // swipeaction
                    }   //foreach
                }   //list
            }     // vstack
            .navigationTitle("All Notes Details")
            .toolbar {
                ToolbarItem(placement : .navigationBarTrailing) {
                    Button(action : {
                        showAddNotes = true
                    }){
                        Image(systemName: "plus")
                    }
                }    // toolbarItem
            }   // toolbar
            .sheet(isPresented : $showAddNotes) {
                AddNotesView()
            }
        }    // navview
    }     // view
    
    private func deleteNotes(_ note : Notes) {
        viewContext.delete(note)
        do {
            try viewContext.save()
        } catch {
            print("Error Deleting Notes: \(error)")
        }
    }
    
    private func formatDate(_ date : Date) -> String {
        let formatter = DateFormatter()
        formatter.dateStyle = .medium
        formatter.timeStyle = .short
        return formatter.string(from: date)
    }
}     // struct

struct NotesView_Previews: PreviewProvider {
    static var previews: some View {
        NotesView()
    }
}
