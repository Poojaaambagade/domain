//
//  EditNotesView.swift
//  Notes
//
//  Created by admin on 01/02/25.
//

import SwiftUI

struct EditNotesView: View {
    @Environment(\.managedObjectContext) private var viewContext
    @Environment(\.dismiss) private var dismiss
    
    @ObservedObject var note:Notes
    @State private var title = ""
    @State private var content = ""
    @State private var date = Date()
    
    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("Edit Notes")){
                    TextField("Enter Notes Title", text:$title)
                    TextField("Enter Notes Content", text:$content)
                    DatePicker("Select Date", selection: $date, displayedComponents: .date)
                    
                }    // section
            }        // form
            .navigationBarTitle("Edit Notes", displayMode: .inline)
            .navigationBarItems(
                leading: Button("Cancle"){
                    dismiss()
                },
                trailing: Button("Update") {
                    note.title = title
                    note.content = content
                    note.date = date
                    saveContext()
                    dismiss()
                }.disabled(title.isEmpty)
            )    // navbaritems
            .onAppear {
                title = note.title ?? ""
                content = note.content ?? ""
                date = note.date ?? Date()
            }
        }    // navview
    }    //view
    private func saveContext(){
        do {
            try viewContext.save()
        }catch {
            print("Error Saving Notes: \(error)")
        }
      }       // savecontext
   }  // struct


