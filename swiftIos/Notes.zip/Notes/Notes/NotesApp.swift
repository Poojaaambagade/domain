//
//  NotesApp.swift
//  Notes
//
//  Created by admin on 01/02/25.
//

import SwiftUI

@main
struct NotesApp: App {
    
    let persistentController = PersistenceController.shared
    
    var body: some Scene {
        WindowGroup {
            NotesView()
                .environment(\.managedObjectContext, persistentController.container.viewContext)
            
        }
    }
}
