//
//  AddNotesView.swift
//  Notes
//
//  Created by admin on 01/02/25.
//

import SwiftUI

struct AddNotesView: View {
    @Environment(\.managedObjectContext) private var viewContext
    @Environment(\.dismiss) private var dismiss
    @State private var title = ""
    @State private var content = ""
    @State private var date = Date()
    
    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("Notes Details")){
                    TextField("Enter Title", text:$title)
                    TextField("Enter Content", text:$content)
                    DatePicker("Select Date", selection: $date, displayedComponents: .date)
                }        //section
            }          // form
            .navigationBarTitle("Add New Notes", displayMode: .inline)
                .navigationBarItems(
                    leading: Button("Cancle"){
                        dismiss()
                    },
                    trailing: Button("Save"){
                        addNotes()
                        dismiss()
                    }
                        .disabled(title.isEmpty)
             )      //navbarItems
        }    //navview
    }    //view
    private func addNotes(){
        let newNotes = Notes(context: viewContext)
        newNotes.title = title
        newNotes.content = content
        newNotes.date = date
        
        do {
            try viewContext.save()
            
        }catch{
            print("Error Saving Notes: \(error)")
        }
    }      // func addnotes
}    //struct

struct AddNotesView_Previews: PreviewProvider {
    static var previews: some View {
        AddNotesView()
    }
}
